# Changelog

## 3.0.5

**Works with: BetrValheim**
- BetrValheim by DezzyCode: with its BetrUI look switched on (F11 → General → Look), the World Control window looks the same: flat dark brown, rounded corners, flat buttons and BetrValheim's font. Switch back and it has the game's look again.

## 3.0.4

**Overview**
- The window now opens on an overview: time, weather, wind, rain damage, the running event, who is online and the player values, each with a button to its page.
- It also shows what you changed but haven't applied yet, with **Apply everything** right next to it.

**Search**
- A search field above the list finds any setting by name or description. **Open** takes you straight to it.

**Clearer pages**
- Every page says whether a setting counts for the whole server or just for you.
- The World Control logo now sits top left.

**Kick, ban and admins in the Players tab**
- **Kick**, **Ban** and **Make admin** / **Drop admin** next to every player. Each one asks first.
- Banning also kicks the player right away.
- A new **Banned** list shows who is banned, and **Unban** lets them back in.
- New admins count at once and stay admins after a restart.
- Nobody can kick, ban or demote themselves.
- The server needs World Control 3.0.4 for these buttons.

**Bugs and ideas**
- Found a bug or have an idea? Tell us on the forum: forum.dezzycode.de

## 3.0.3

- **Ramp** and **Restore original terrain** now show up in the hoe menu right away. Before, they sometimes only appeared after you learned a new recipe, and vanished when you changed the language.
- Works together with 3.0.0 to 3.0.2, so nobody has to update at the same time.

## 3.0.2

**A new window**
- Tabs on the left, the open one in orange, every setting in its own row with a short explanation. Long pages scroll.
- Numbers have a slider and a field to type in, for example the time as `14:30`.
- The top shows whether the server took your change and who changed something last.
- The window fits small screens and can be dragged anywhere.

**Wind on a compass**
- Pick where the wind comes from by clicking or dragging on a compass. Near one of the eight directions it snaps to it.
- While the wind is natural, the compass shows the wind blowing right now.

**Smaller things**
- **Everything back to natural** moved away from **Apply everything** and asks first, so you can't hit it by accident.
- Scrolling a page over a slider no longer changes its value.
- Every event has its own **Start** button.
- Pick the language from a list.
- Works together with 3.0.0 and 3.0.1, so nobody has to update at the same time.

## 3.0.1

- The window can now be translated into any language. English and German are included. Want your language? Copy `en_EN.json` in the mod's `locales` folder, translate it and share it on the forum.
- Saved presets show the weather in your language.
- Works together with 3.0.0, so nobody has to update at the same time.

## 3.0.0

**Portals moved to BetrValheim**
- Picking a portal on the map is now part of BetrValheim by DezzyCode.
- With World Control alone, portals work like in the normal game again: two portals with the same name are linked.

**Tidier tabs**
- Sorted by topic: the world first (time, weather, wind, events, presets), then the people (players, places, announcements, player values), then the terrain tools.
- Player values have their own tab.

**Everyone needs 3.0.** A 2.x player can't join a 3.0 server, and the other way round.

## 2.8.1

- Scrolling the portal list no longer zooms the map at the same time.
- The portal list scrolls much faster.
- New icon.

## 2.8.0

- The portal list keeps one fixed order, the same for everyone. Admins can change it with **Edit**.
- Portal markers on the map are smaller and violet-blue; the portal you stand at is a bit bigger.
- Hiding pins on your map no longer hides the portals.
- While you pick a portal, the map stays on top and you can't walk off by accident.
- Everyone needs 2.8.

## 2.7.0

- Walk into a portal and pick where to go on the map or in a list.
- Clicking a portal in either place takes you there. The game's usual rules, like ore not going through, still apply.

## 2.6.3

- Flattening, ramps and restoring terrain run smoother.
- Restoring ground that was only painted now brings the grass back properly.
- The ramp preview shows the right corners.

## 2.6.2

- Fixed the eitr cost sliders, which didn't always affect the item in your hands.
- New: eitr regeneration in the player values.
- Player values can only be changed in the players' favour: more health, stamina and eitr, faster regeneration, lower costs, more adrenaline.
- The rain damage switch now reads simply **On / Off**.

## 2.6.1

- New: switch off rain damage to buildings. Wood standing in water still wears down as usual.
- **Reset player values** asks first.

## 2.6.0

- New **Terrain** tab: flatten with the pickaxe, bigger hoe and cultivator, ramps, and bringing back the original ground.
- New **player values**: max health, stamina and eitr, stamina regeneration, and costs for stamina, eitr and adrenaline. Set by admins, the same for everyone.
- The F8 window is roomier and can be dragged around.
- Settings now stay until you change or reset them; the timer is gone.
- Everyone needs World Control now, the server and every player.

## 2.5.7

- In single player or when you host, the window no longer says it's waiting for the server.
- Escape leaves a text field instead of closing the window.
- Enter sends an announcement.
- Pressing F8 without admin rights now tells you that only admins can change the world.

## 2.5.6

- Saved places can be named and cleared.

## 2.5.5

- Loading a preset sets it right away.

## 2.5.4

- The window is bigger, with more room for lists and sliders.

## 2.5.3

- New **Announcements**: a message for everyone in the middle of the screen and in the chat, with your name in front.
- New **Places**: three spots of your own to jump back to.
- Everyone needs to update together.

## 2.5.2

- Events are listed by the name and message the game shows for them, in your language, instead of a code word.

## 2.5.1

- Switch the language right in the window: Auto, English or German.

## 2.5.0

- Settings can run out after 15 minutes to 4 hours and then go back to natural.
- Your settings stay after a server restart.
- New **Players** tab: see who is online, bring someone to you or jump to them.
- The window shows who made the last change.
- Everyone needs to update together.

## 2.4.0

- New **Events** tab: see the running event, start any event where you stand, stop it, or hold new ones back.
- New **Presets**: save time, weather and wind and load them again with one click.
- Everyone needs to update together.

## 2.3.1

- The author's mark moved to the bottom left.

## 2.3.0

- One **Apply everything** button instead of three.
- Fast-forward jumps once and then goes back to natural.
- The window speaks English and German, or follows the game.
- Everyone needs to update together.
