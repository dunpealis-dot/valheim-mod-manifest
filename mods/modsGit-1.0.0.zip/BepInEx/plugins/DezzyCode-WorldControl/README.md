# World Control

> **Found a bug or have a wish?** Report it on the forum: **[forum.dezzycode.de](https://forum.dezzycode.de)**

**Time, weather, wind, random events, teleports, announcements, terrain tools and kinder
player stats — all in one admin window on F8, and the same for everyone on the server.**

**Works with:** [BetrValheim](https://thunderstore.io/c/valheim/p/DezzyCode/BetrValheim/) by DezzyCode

Made by **DezzyCode**.

---

## At a glance

### Time and weather

| | |
| --- | --- |
| **Time of day** | Let it run, hold it still, or jump forward to the hour you want |
| **Weather** | Clear, rain, thunderstorm or fog — or whatever the biome brings |
| **Rain damage** | Switch off rain wearing down your buildings |
| **Wind** | Pick direction and strength yourself, or leave it to the game |
| **Presets** | Three saved mixes of time, weather and wind |

### Events and messages

| | |
| --- | --- |
| **Random events** | Start one where you stand, stop it, or hold new ones back |
| **Announcements** | A message for everyone, right in the middle of the screen |

### Players and places

| | |
| --- | --- |
| **Players** | See who is online, bring someone to you or jump to them |
| **Places** | Three spots of your own to jump back to |
| **Player values** | More health, stamina and eitr, faster regeneration, lower costs, more adrenaline |

### Building

| | |
| --- | --- |
| **Terrain tools** | Flatten with the pickaxe, build ramps, bring back the original ground |

### Works with

| | |
| --- | --- |
| **BetrUI look** | With BetrValheim, the window follows its BetrUI look |

---

## One window for the admin

Press **F8**. The window opens on an **Overview** of how the world stands, with a button to the
page of each line, and what you changed and have not applied yet. The tabs sit on the left, the
open one in orange; every setting is a row with a short explanation and its control on the
right, under a heading that says whether it applies to everyone or to you alone, and long pages
scroll. The search field over the list finds any setting by its name. The time of day is at
the top right. Drag the window wherever it is in the way least; on a small screen it shrinks
to fit.

The tabs are sorted by topic: first the world — **Time, Weather, Wind, Events, Presets** —
then the people — **Players, Places, Announce, Player values** — and last the **Terrain**
tools.

Change what you like, then press **Apply everything** at the bottom right. **Everything back
to natural**, beside it, puts time, weather, wind, rain damage and events back
the way the game runs them. Whatever you set stays until you change it or reset it — also
after the server restarts.

Only admins can open the window. Everyone else still gets the result: the weather you set is
the weather they see.

---

## Time

| Choice | What happens |
| --- | --- |
| Natural | The normal day and night |
| Hold | The time of day stands still. The world keeps ageing and your smelters keep working |
| Fast-forward | The world clock jumps once to the hour you picked. Smelters, fermenters and world age jump with it |

---

## Weather, rain and wind

Choose **Clear**, **Rain**, **Thunderstorm** or **Fog**, or **Natural** to get the usual
weather of the biome you are in.

**Rain damage** can be switched off. Rain then no longer wears down your buildings. Wood that
stands in water still rots as usual — only the rain is let off.

**Wind** is natural or set by hand. Set by hand, you pick **where it comes from** on a compass:
click or drag on the ring, and close to one of the eight directions it snaps to it. Then set
how strong it blows. While the wind is natural, the compass shows the wind blowing right now.
Handy when you are sailing somewhere.

---

## Random events

Every event the game knows is in a list, each with its own **Start** button. It begins
**where you are standing**.
The window shows what is running and how long it still lasts, and one button ends it.

You can also **hold new events back**, so no troll raid spoils the building session.

---

## Players, places and presets

**Players** lists everyone online. **Bring** pulls someone to you, **Go** takes you to them.
**Kick**, **Ban** and **Make admin** / **Drop admin** sit beside each player and ask first.
Banning also kicks, and the **Banned** list lifts a ban again. Admin rights go into the server's
`adminlist.txt` and take effect at once. Nobody can act on themselves. These need World Control
3.0.4 on the server as well.

**Places** are three spots of your own. Stand somewhere, press **Save here**, give it a name,
and jump back later with **Go**.

**Presets** are three saved mixes of time, weather and wind. Load one and it is set in the
world straight away.

Places and presets are yours alone; they are kept on your computer, not on the server.

---

## Announcements

Type a message of up to 120 characters and send it to everyone. It appears in the middle of
the screen and in the chat, with your name in front of it.

---

## Terrain tools

Tools for shaping the ground, for admins only.

**Flatten with the pickaxe.** Hold the pickaxe and keep the **right mouse button** pressed:
the ground under you becomes flat as you walk. You choose:

| Setting | Range |
| --- | --- |
| Size | 1 to 20 m |
| Edge smoothing | 0 to 100 %, from a hard edge to a soft slope |
| Shape | Square or circle |
| Ground | Paint it as dirt, or keep the colour it has |
| Grid movement | While flattening you walk in eight fixed directions, so paths come out straight |

A frame on the ground shows exactly what will be flattened.

**Bigger hoe and cultivator.** Both reach from 2 up to 20 m. Change it with **Page Up** and
**Page Down** while the tool is in your hand; a circle on the ground shows the area.

**Ramp.** In the hoe's build menu. Aim at a spot and place it: a smooth ramp runs from your
feet to that spot, 1 to 20 m wide, and you see it before you build it.

**Restore original terrain.** Also in the hoe's build menu. Everything you raised, lowered or
painted inside the circle (1 to 20 m) goes back to how the world made it.

One switch turns all terrain tools on or off.

---

## Player values

The **Player values** tab has four pages. Every value starts at the normal game value and can
only be changed in the player's favour.

| Page | What you can change | Range |
| --- | --- | --- |
| Vitals | Maximum health, stamina and eitr, stamina and eitr regeneration | 1× to 5× |
| Stamina | Running, jumping, dodging, swimming, sneaking, carrying too much, grappling, blocking, primary and secondary attacks, drawing a bow, reloading, building | 0× to 1× |
| Eitr | Primary and secondary attacks or spells, drawing and channeling, reloading and repeated casts | 0× to 1× |
| Adrenaline | Gains from attacks, projectile hits, blocks, perfect blocks, perfect dodges, staggering enemies and your guardian power | 1× to 5× |
| | Losses from missing and from unblocked damage | 0× to 1× |

`0×` means it costs nothing at all. **Reset player values** puts everything back to normal.

---

## Worth knowing

**Everyone needs it** — the server and every player, in the same version. A 2.x player cannot
join a 3.0 server, and the other way round.

**The server decides for everyone.** Time, weather, wind, events, rain damage and player
values are set on the server and handed to every player. They are remembered when the server
restarts.

**Admins are the ones on the server's admin list.** If you host a game yourself, you are the
admin.

**Your own things stay yours:** the language, the F8 key, your places and your presets.

**Coming from WindControl?** World Control replaces it. Remove WindControl; your settings
carry over.

The window speaks **English** and **German**, or follows the game's language. Want it in your
language? Copy `en_EN.json` in the mod's `locales` folder, translate it and share it on the
forum.

---

## Works with:

### BetrValheim

With [BetrValheim](https://thunderstore.io/c/valheim/p/DezzyCode/BetrValheim/) by **DezzyCode** installed,
switch on its BetrUI look (F11 → General → Look) and the World Control window follows it: flat dark
brown, rounded corners, flat buttons, BetrValheim's font. Without BetrValheim it simply keeps the
game's look.

## Requirements

- BepInExPack Valheim
- Jötunn 2.30 or newer

## DezzyCode

World Control is made by **DezzyCode**.

- **All my mods:** https://thunderstore.io/c/valheim/p/DezzyCode/?section=all
- **Forum, bug reports and ideas:** https://forum.dezzycode.de

© 2026 DezzyCode. All rights reserved. Please don't reupload World Control; link to this page instead. Details in LICENSE.txt.
